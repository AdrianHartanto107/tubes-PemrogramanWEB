<?php
require 'function.php';

$id = $_GET["id"];

$film = query("SELECT * FROM films WHERE id = '$id'")[0];





if( isset($_POST["ubah"]) ) {
	
	
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = 'admin.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = 'admin.php';
			</script>
		";
	}


}
?>


<!DOCTYPE html>
<html>
<head>
	<title>Ubah Data film</title>
	<style type="text/css">
			.container {
				background-color: magenta;
				width: 500px;
				height: 600px;
				margin-left: 40%; 
				border-radius: 10%;
			}

			body {
				background-color: cyan;
			}
			h1 , h3{
				text-align: center;
			}
			input {
				height: 20px;
				width: 450px;
				margin-left: 8px;
				margin-top: 10px;
			}
			button {
				margin-left: 10px;
				text-decoration: none;
			}
			.tombol1 {
				background-color: cyan;
			}
			.tombol2 {
				background-color: red;
			}
			
			
		</style>
</head>
<body>
	<div class="container">
		<h1>Ubah Data film </h1>
		<h3>Isi Format Berikut</h3>
	<table>
	<form action="" method="post">

		
		<tr>
		<td><label for="id">id</label><br>
		<input type="text" name="id" id="id" value="<?= $film['id']; ?>"></td>
		</tr>
		<tr>
		<td><label for="gambar">gambar</label><br>
		<input type="text" name="gambar" id="gambar" value="<?= $film['gambar']; ?>"></td>
		</tr>
		<tr>
		<td><label for="cerita">cerita singkat</label><br>
		<input type="text" name="cerita" id="cerita" value="<?= $film["cerita"]; ?>"></td>
		</tr>
		<tr>
		<td><label for="judul">judul</label><br>
		<input type="text" name="judul" id="judul" value="<?= $film["judul"]; ?>"></td>
		</tr>
		<tr>
		<td><label for="genre">genre</label><br>
		<input type="text" name="genre" id="genre" value="<?= $film["genre"]; ?>"></td>
		</tr>
		<tr>
		<td><label for="produced">produced</label><br>
		<input type="text" name="produced" id="produced" value="<?= $film["produced"]; ?>"></td>
		</tr>
		<tr>
		<td><label for="writer">writer</label><br>
		<input type="text" name="writer" id="writer" value="<?= $film["writer"]; ?>"></td>
		</tr>
		
		<td><button type="submit" name="ubah">Ubah Data</button>
			<a href="admin.php"><button>Keluar</a></button></td></td>
		</form>

	</table>	




</body>
</html>