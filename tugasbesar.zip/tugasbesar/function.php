<?php 


	$conn = mysqli_connect("localhost","root","", "film_adrian");

	function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	};

	return $rows;

}


function tambah($data){
	global $conn;



	
	$id = htmlspecialchars($data['id']);
	$gambar = htmlspecialchars($data['gambar']);
	$cerita = htmlspecialchars($data['cerita']);
	$judul = htmlspecialchars($data['judul']);
	$genre = htmlspecialchars($data['genre']);
	$produced = htmlspecialchars($data['produced']);
	$writer = htmlspecialchars($data['writer']);

	$query = "INSERT INTO films
						VALUES('$id','$gambar', '$cerita', '$judul', '$genre', '$produced', '$writer')";
// die($query);
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}






function hapus($id){
	global $conn;
	mysqli_query($conn, "DELETE FROM films WHERE id = '$id'");


		// die($query);

	return mysqli_affected_rows($conn);
	}



	function ubah($data){
	 global $conn;
	$id = ($data['id']);
	$gambar = htmlspecialchars($data['gambar']);
	$cerita = htmlspecialchars($data['cerita']);
	$judul = htmlspecialchars($data['judul']);
	$genre = htmlspecialchars($data['genre']);
	$produced = htmlspecialchars($data['produced']);
	$writer = htmlspecialchars($data['writer']);
	
	

	$query = "UPDATE films SET 
				
				gambar = '$gambar',
				cerita = '$cerita',
				judul = '$judul',
				genre = '$genre',
				produced = '$produced',
				writer = '$writer'
				
				
			WHERE id = $id";

			// die($query);
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);

}


function cari($keyword) {
	$query = "SELECT * FROM films
				WHERE
			  id LIKE '%keyword%' OR
			  judul LIKE '%$keyword%' OR
			  genre LIKE '%$keyword%' OR
			  produced LIKE '%$keyword%' OR
			  writer LIKE '%$keyword%'";
	return query($query);
}

function registrasi($data){
global $conn;

// $id = htmlspecialchars($data['id']);
$username = htmlspecialchars($data['username']);
$password = htmlspecialchars($data['password']);

$result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

if(mysqli_num_rows($result) > 0 ){
	echo "<script>
				alert('username sudah terdaftar!');
			</script>";
	return false;
}

$password = password_hash($password, PASSWORD_DEFAULT); 

$query = "INSERT INTO user
						VALUES('','$username','$password')";
// die($query);
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

?>