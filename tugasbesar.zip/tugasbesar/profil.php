<?php 	
if (!isset($_GET['id'])) {
	header("Location: user.php");
	exit;

}

require 'function.php';
$fim = $_GET['id'];

$film = query ("SELECT * FROM films WHERE id = $fim")[0];
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>profile</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<style type="text/css">
	body{ background-image: url(img/polkadot.jpg) }
		
	.container {
		width: 800px;
		height: 500px;
		background-color: blue	;
		text-align: center;
		display: block;
		margin: auto;
		box-shadow: 1px 1px 20px 10px;
		border-radius: 5%;
		margin-top: 50px;

	}
	h1 {
		text-align: center;
		font-family: arial;
		padding-top: 20px;
	}
	p{
		
		float: left;
		clear: both;
		margin-left: 130px;
	}
	a {
		text-decoration: none;
		color: black;
	}
	img {
		width: 250px;
		height: 200px;
		text-decoration: none;
		border-radius: 100%;
	}

	</style>
</head>
<body>
	<button type="button" class="btn btn-danger"><a href="user.php">keluar</button></a>
	<div class="container">

			<h1> film</h1>
			
			<table cellpadding="10"  align="center">
				<tr> 
			<td colspan="2"><img src="img/<?= $film['gambar']; ?>"></td></tr>
			<tr>			
			<td> judul: &nbsp<?= $film['judul']; ?></td></tr>
			<tr>
			<td> genre : &nbsp<?= $film['genre']; ?></td></tr>
			<tr>
			<td> produced : &nbsp<?= $film['produced']; ?></td></tr>
			
			<td>writer : &nbsp<?= $film['writer']; ?></td>
			
			
			</table>
			

		</div>

	</div>

</body>
</html>