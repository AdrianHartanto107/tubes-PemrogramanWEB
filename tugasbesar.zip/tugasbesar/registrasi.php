<?php
require 'function.php';

// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit2"]) ) {
	
	// cek apakah data berhasil di tambahkan atau tidak
	if( registrasi($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'admin.php';
				
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal ditambahkan!');
			
			</script>
			
		";
	}

// die($query);
}
?>


<!DOCTYPE html>
<html>
<head>
	<title>regis</title>
	<style type="text/css">
		
		.container {
			width: 300px;
			height: 350px;
			background-color: salmon;
			margin: 50px 40%;
			border-radius: 20%;

		}

		body{
			background-color: skyblue;
		}
		h1 {
			text-align: center;
			padding-top: 20px;
		}
		img	{
			width: 100px;
			height: 100px;
			padding-left: 100px;
		}
		label{
			padding-left: 20px;

		}
		button {
			margin-top: 10px;
			margin-left: 65px;
			background-color: blue;
			width: 175px;
			height: 40px;
			font-weight: 10px;
		}
		input {
			margin-top: 20px;
			margin-bottom: -10px;
			margin-left: 65px;
			height: 30px;
		}

	</style>
</head>
<body>
	
	<div class="container">
<h1>Registrasi</h1>
<img src="img/login.png">

<?php if( isset($error) ) : ?>
	<p style="color: red; font-style: italic;">username / password salah!</p>
<?php endif; ?>


<form action="" method="post">
		<input type="text" name="username" id="username">
		<input type="password" name="password" id="password" value="password"><br><br>
		<button type="submit" name="submit2">registrasi</button>

	
</form>
</ul>


</div>
</body>
</html>