<?php 
// cek apakah tombol submit sudah tekan atau belum
if( isset($_POST["submit"]) ) {
	// cek username & password
	if( $_POST["username"] == "adrian" && $_POST["password"] == "adrian" ) {
	// jika benar, redirect ke halaman admin
		header("Location: admin.php");
		exit;
	} else if ( $_POST["username"] == "user" && $_POST["password"] == "12345" ) {
		header("Location: user.php");
		exit;	

	
	}

	}
	
if( isset($_POST["submit2"]) ) {
	header("Location: registrasi.php"); 
	}

		

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		
		.container {
			width: 300px;
			height: 400px;
			background-color: salmon;
			margin: 50px 40%;
			border-radius: 20%;

		}

		body{
			background-color: skyblue;
		}
		h1 {
			text-align: center;
			padding-top: 20px;
		}
		img	{
			width: 100px;
			height: 100px;
			padding-left: 100px;
		}
		label{
			padding-left: 20px;

		}
		button {
			margin-top: 10px;
			margin-left: 65px;
			background-color: blue;
			width: 175px;
			height: 40px;
			font-weight: 10px;
		}
		input {
			margin-top: 20px;
			margin-bottom: -10px;
			margin-left: 65px;
			height: 30px;
		}

	</style>
</head>
<body>
	
	<div class="container">
<h1>Login</h1>
<img src="img/login.png">

<?php if( isset($error) ) : ?>
	<p style="color: red; font-style: italic;">username / password salah!</p>
<?php endif; ?>


<form action="" method="post">
		<input type="text" name="username" id="username" value="username">
		<input type="password" name="password" id="password" value="password"><br><br>
		<button type="submit" name="submit">Login</button>
		<button type="submit" name="submit2">registrasi</button>

	
</form>
</ul>


</div>
</body>
</html>