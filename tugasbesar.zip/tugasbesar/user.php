<?php
	require 'function.php';
	$film = query ("SELECT * FROM films");


if( isset($_POST["search"]) ) {
	$film = cari($_POST["input"]);
}
?>
<!--  -->
<html>
	<head>
		<title> user </title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<!--  -->
		<style>	
		h1{color: white;}
		body {
			text-align: center;
			background-image: url(img/moon.jpg);
		}
		table{
			color: white;
			border: 100px;
		}

		img {
			width: 200px;
			height: 250px;
		}
		a {
			text-decoration: none;
			color: black;
		}
		.tombol1 {
			background-color: lightgreen;
			border-radius: 100px;
			margin-bottom: 20px;
			
		}
		.tombol2 {
			background-color: cyan;
			border-radius: 5px;
			height: 40px;
			width: 70px;
		}
		.tombol3 {
			background-color: red;
			border-radius: 5px;
			height: 40px;
			width: 70px;
			margin-left: 1100px;
			margin-bottom: 50px;
			
			font-size: 10px;
		}
		
		
		.navbar {
			width: 100%;
			height: 60px;
			background-color: orchid;


		}
		.nav button {
			margin-left: 94%;
					}
		h1 {
			padding-top: 10px;
		}
		.btn {margin-top: 20px;}


		</style>
<!--  -->
	</head>
	<body>
		<form action="" method="post">
		<nav class="navbar navbar-light bg-warning">
  <a class="navbar-brand"></a>
  <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="input">
    <button class="btn btn-success my-2 my-sm-2" type="submit" name="search">cari</button>
  </form>
</nav>
</div>
					<h1> Daftar Film </h1>
<button class="tombol3"><a href="index.php">Log Out</a></button>
	
	
		<br>
		<table border="10" cellspacing="1" cellpadding="10" align="center">
			<tr>
				<th> no </th>
				<th> id </th>
				<th> Gambar </th>
				<th> cerita singkat </th>
				<th> judul </th>
				<th> genre </th>
				<th> produced </th>
				<th> writer </th>
			</tr>
<!--  -->
			<?php $i =1; ?>
			<?php foreach($film as $fim) : ?>

			<tr align="center">
				<td><?= $i  ?></td>
				<td><?= $fim['id']; ?></td>
				<td><a href="profil.php?id=<?= $fim['id'];?>"><img src="img/<?= $fim['gambar']; ?>"></a></td>
				<td><?= $fim['cerita']; ?></td>
				<td><?= $fim['judul']; ?></td>
				<td><?= $fim['genre']; ?></td>
				<td><?= $fim['produced']; ?></td>
				<td><?= $fim['writer']; ?></td>
			</tr>
			<?php $i++; ?>
		<?php endforeach; ?>
<!--  -->
		</table>
	</body>
</html>