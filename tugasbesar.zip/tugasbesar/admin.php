<?php
	require 'function.php';

	$films = query ("SELECT * FROM films");


if( isset($_POST["search"]) ) {
	$films = cari($_POST["input"]);
}
?>
<!--  -->
<html>
	<head>
		<title> admin </title>
<!--  -->
		<style>	
		body {
			text-align: center;
			background-image: url(img/cla.jpg);
		}

		img {
			width: 200px;
			height: 250px;
		}
		a {
			text-decoration: none;
			color: black;
		}
		.tombol1 {
			background-color: magenta;
			margin-bottom: 20px;
		}
		.tombol2 {
			background-color: #66FF66;
			border-radius: 5px;
			height: 40px;
			width: 70px;
		}
		.tombol3 {
			background-color: #FF0066;
			border-radius: 5px;
			height: 40px;
			width: 70px;
		}
		.cari input,button{
			height: 30px;
		}
		.nav {
			width: 100%;
			height: 60px;
			background-color: skyblue;


		}
		.nav button {
			margin-left: 94%;
					}
		h1 {
			padding-top: 10px;
		}

		table {background-color: white;}

		</style>
<!--  -->
	</head>
	<body>
		<div class="nav">
					<h1> film </h1>
<button class="tombol3"><a href="index.php">Log Out</a></button></div>
	<div class="cari">
	<form action="" method="post">
		<br>
	<input type="text" name="input" size="30" autofocus placeholder="Masukan Pencarian..." autocomplete="off">
	<button type="submit" name="search">Search</button>
	
	</form>
</div>


		<br>
		<button class="tombol1"><a href="tambah.php">Tambah Data film</a></button>
		<br>
		<table border="1" cellspacing="0" cellpadding="10" align="center">
			<tr>
				<th> no </th>
				<th> id </th>
				<th> Opsi </th>
				<th> Gambar </th>
				<th> cerita</th>
				<th> judul </th>
				<th> genre </th>
				<th> produced </th>
				<th> writer </th>
			</tr>
<!--  -->
			<?php $i =1; ?>
			<?php foreach($films as $film) : ?>

			<tr align="center">
				<td><?= $i  ?></td>
				<td><?= $film['id']; ?></td>
				<td><button class="tombol2"><a href="ubah.php?id=<?= $film['id']; ?>">Ubah</a></button>
				 <button class="tombol3"><a href="hapus.php?id=<?= $film ['id']; ?>">Hapus</a></button></td>

				<td><a href="profil.php?judul=<?= $film['judul']?>"><img src="img/<?= $film['gambar']; ?>"></td>
				<td><?= $film['cerita']; ?></td>
				<td><?= $film['judul']; ?></td>
				<td><?= $film['genre']; ?></td>
				<td><?= $film['produced']; ?></td>
				<td><?= $film['writer']; ?></td>
			</tr>
			<?php $i++; ?>
		<?php endforeach; ?>
<!--  -->
		</table>
	</body>
</html>