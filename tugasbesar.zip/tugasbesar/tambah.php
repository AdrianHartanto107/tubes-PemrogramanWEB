<?php
require 'function.php';

// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	
	// cek apakah data berhasil di tambahkan atau tidak
	if( tambah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'admin.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'admin.php';
			</script>
		";
	}

// die($query);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>tambah data film</title>
	<style type="text/css">
			.container {
				background-color: orange;
				width: 320px;
				height: 800px;
				margin-left: 40%; 
				border-radius: 10%;
			}
			h1 , h3{
				text-align: center;
			}
			body { background-color: lime; }
			input {
				height: 50px;
				width: 290px;
				margin-left: 8px;
				margin-top: 10px;
			}
			button {
				margin-left: 10px;
				text-decoration: none;
				background-color: skyblue;
			}
			.tombol1 {
				background-color: cyan;
			}
			.tombol2 {
				background-color: red;
			}
			
			
		</style>
</head>
<body>
	<div class="container">
		<h1>tambah Data film </h1>
		<h3>Isi Format Berikut</h3>
	<table>
	<form action="" method="post">

		<tr>
		<td><label for="id">id</label><br>
		<input type="text" name="id" id="id" required></td>
		</tr>
		<tr>
		<td><label for="gambar">gambar</label><br>
		<input type="file" name="gambar" id="gambar" required></td>
		</tr>
		<tr>
		<td><label for="cerita">cerita singkat</label><br>
		<input type="text" name="cerita" id="cerita"></td>
		</tr>
		<tr>
		<td><label for="judul">judul</label><br>
		<input type="text" name="judul" id="judul"></td>
		</tr>
		<tr>
		<td><label for="genre">genre</label><br>
		<input type="text" name="genre" id="genre"></td>
		</tr>
		<tr>
		<td><label for="produced">produced</label><br>
		<input type="text" name="produced" id="produced"></td>
		</tr>
		<tr>
		<td><label for="writer">writer</label><br>
		<input type="text" name="writer" id="writer"></td>
		</tr>
		
		<td><button type="submit" name="submit">tambah Data</button>
			<a href="admin.php"><button>Keluar</a></button></td></td>
		</form>

	</table>	





</body>
</html>